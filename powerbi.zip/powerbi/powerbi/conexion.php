<?php
	
	$mysqli = new mysqli("localhost", "root", "singara133", "dash");
	
?>
