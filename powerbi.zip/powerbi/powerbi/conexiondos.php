<?php
	
	$mysqli = new mysqli("localhost", "root", "singara133", "estats_kaspersky");
	
?>